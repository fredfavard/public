#!/usr/bin/env bash

set -euo pipefail

function usage() {
    echo "./generate_ticket.sh -c CONFIG_FILE [-d] [-p] [-t TICKET_ID]"
}

#PREP_PIPELINE_FILENAME='Layer2_cdd-ref-psp_Software_Preparation.json'
PREP_PIPELINE_FILENAME='Custom_Stage_Pre.json'
PREP_PIPELINE="spinnaker/pipelines/${PREP_PIPELINE_FILENAME}"
ticket_id="T-111111"
config_file=""
docker_build=true
docker_pull=true

while getopts "dpc:t:" arg; do
    case "${arg}" in
        c)
            config_file="${OPTARG}"
            ;;
        d)
            # If docker image is already built, this allows to skip docker build
            docker_build=false
            ;;
        p)
            # If docker has no access to artifactory, this allows to skip docker pull
            docker_pull=false
            ;;
        t)
            ticket_id="${OPTARG}"
            ;;
        *)
            usage
            exit 1
            ;;
    esac
done
shift $((OPTIND-1))

if [[ ! "${config_file}" ]]; then
    echo "No config_file specified."
    usage
    exit 1
fi

working_dir_path=$(pwd)
script_dir_path=$(dirname "${0}")
src_dir_path="${script_dir_path}/.."
ticket_template="${src_dir_path}/templates/ticket.tmpl"

# Create temporary dir
temp_dir_path=$(mktemp -d -p "${working_dir_path}")
temp_pipeline_dir_path="${temp_dir_path}/swdp_pipelines"

# L1 Unpack product stage does not support unpacking other zips from ticket
temp_helm_dir_path="${temp_pipeline_dir_path}/helm_charts"
temp_docker_dir_path="${temp_pipeline_dir_path}/docker_images"

# shellcheck source=src/config/kubernetes-dashboard-2.2.0.conf
source "${config_file}"

function finish() {
    rm -rf "${temp_dir_path}"
}

trap 'finish' EXIT

function zip_directory() {
    local directory
    local destination
    local directory_name
    directory="${1}"
    destination="${2}"
    directory_name="$(basename "${directory}")"

    cd "${directory}/.."
    echo "Creating zip archive with '${directory_name}' directory."
    zip -r -q "${destination}" "${directory_name}"
    echo "Zip archive '${destination}' created."
    # Suggested fix beats the purpose of -e and doesn't trigger error function.
    # This is fixed in later versions of shellcheck.
    # shellcheck disable=SC2103
    cd - > /dev/null
}

function targz_zip_directory() {
    local directory
    local destination
    local directory_name
    local tar_file
    directory="${1}"
    destination="${2}"
    directory_name="$(basename "${directory}")"
    tar_file="${directory_name}.tar.gz"

    cd "${directory}/.."
    echo "Creating tar.gz archive from '${directory_name}' directory."
    tar -czf "${tar_file}" "${directory_name}"
    echo "Creating zip archive with '${tar_file}' archive."
    zip -r -q "${destination}" "${tar_file}"
    echo "Zip archive '${destination}' created."
    rm "${tar_file}"
    # Suggested fix beats the purpose of -e and doesn't trigger error function.
    # This is fixed in later versions of shellcheck.
    # shellcheck disable=SC2103
    cd - > /dev/null

}

ticket_dir_path="${working_dir_path}/${ticket_id}"
rm -rf "${ticket_dir_path}"
mkdir -p "${ticket_dir_path}"

# This should be taken care by version control but for the purposes of providing
# example of upgrade path some version number overriding is necessary.
sed "s/<VERSION>/${product_version}/" < "${ticket_template}"| sed "s/<TICKET_ID>/${ticket_id}/" > "${ticket_id}/${ticket_id}.xml"

# Prepare pipelines to temporary dir
mkdir -p "${temp_pipeline_dir_path}"
cp -a "${src_dir_path}/${pipeline_dir}/." "${temp_pipeline_dir_path}"
# This should be taken care by version control but for the purposes of providing
# example of upgrade path some version number overriding is necessary.
sed --in-place "s/<VERSION>/\"${product_version}\"/" "${temp_pipeline_dir_path}/${PREP_PIPELINE}"

# Package Helm Charts
echo "Packaging Helm charts."
if command -v helm &> /dev/null; then
    mkdir -p "${temp_helm_dir_path}"
    helm package "${src_dir_path}/${helm_charts_src_dir}" --destination "${temp_helm_dir_path}"
else
    echo "Command helm not present." && exit 1
fi

# Build/pull docker images and save them
echo "Building and pulling docker images."
if command -v docker &> /dev/null; then
    mkdir -p "${temp_docker_dir_path}"
    for image in "${images_to_build[@]}"; do
        image_name="${image%:*}"
        dockerfile_dir_path="${src_dir_path}/${dockerfiles_dir}/${image_name}"
        if [ ${docker_build} ]; then
            docker build "${dockerfile_dir_path}" -t "${image}"
        fi
    done
    if "${docker_pull}"; then
        for image in "${images_to_pull[@]}"; do
            docker pull "${image}"
        done
    fi
    for image in "${images_to_build[@]}" "${images_to_pull[@]}"; do
        image_without_repo="${image#"${docker_registry_url}/"}"
        tar_file="${temp_docker_dir_path}/${image_without_repo//[.:\-\/]/_}.tar"
        docker tag "${image}" "${image_without_repo}"
        echo "Saving image '${image_without_repo}' to '${tar_file}'."
        docker save "${image_without_repo}" -o "${tar_file}"
    done
else
    echo "Command docker not present." && exit 1
fi

# Ticket creation
zip_directory "${src_dir_path}/${metadata_dir}" "${ticket_dir_path}/${metadata_out_dir}"
zip_directory "${src_dir_path}/${release_notes_dir}" "${ticket_dir_path}/${release_notes_out_dir}"

targz_zip_directory "${temp_pipeline_dir_path}" "${ticket_dir_path}/${pipeline_out_dir}"
targz_zip_directory "${src_dir_path}/${product_source_code_dir}" "${ticket_dir_path}/${product_source_code_out_dir}"

echo "Ticket ${ticket_id} created."
